// File: features/providers/treeRenderer.js
const vscode = require('vscode');

function getRoots(context) {
    return [
        { label: 'General Workspace', originalText: 'General Workspace', contextValue: 'standardTab', collapsibleState: vscode.TreeItemCollapsibleState.Collapsed, iconPath: new vscode.ThemeIcon('archive') },
        ...(context.globalState.get('userFolders', []) || []).map(f => ({
            label: f, originalText: f, contextValue: 'standardTab', isUser: true,
            collapsibleState: vscode.TreeItemCollapsibleState.Collapsed, iconPath: new vscode.ThemeIcon('folder')
        })),
        { label: 'Priority Tab', contextValue: 'priorityTab', collapsibleState: vscode.TreeItemCollapsibleState.Collapsed, iconPath: new vscode.ThemeIcon('star-full') },
        { label: 'Recycle Bin', contextValue: 'recycleTab', collapsibleState: vscode.TreeItemCollapsibleState.Collapsed, iconPath: new vscode.ThemeIcon('trash') }
    ];
}

function getPriorityItems(context) {
    const priTasks = context.globalState.get('priorityTasks', []) || [];
    const activeFolders = new Set();
    // Only group tasks (not folder-type entries) into folders
    priTasks.forEach(t => {
        if (t.type !== 'folder' && (t.folder || t.target)) {
            activeFolders.add(t.folder || t.target);
        }
    });

    const folderNodes = Array.from(activeFolders).map(fName => ({
        label: fName, originalText: fName, contextValue: 'priorityFolder',
        collapsibleState: vscode.TreeItemCollapsibleState.Collapsed,
        iconPath: new vscode.ThemeIcon('folder-active')
    }));

    // Standalone = tasks with no folder/target AND not a folder-type marker
    const standalone = priTasks
        .filter(t => t.type !== 'folder' && !t.folder && !t.target)
        .map(t => formatPriorityTask(t, 'priorityTask'));

    return [...folderNodes, ...standalone];
}

function getPriorityFolderItems(context, folderName) {
    const priTasks = context.globalState.get('priorityTasks', []) || [];
    return priTasks
        .filter(t => t.type !== 'folder' && (t.folder === folderName || t.target === folderName))
        .map(t => formatPriorityTask(t, 'priorityTask'));
}

function getSearchResults(context, query) {
    if (!query || query.trim() === '') return getRoots(context);
    const q = query.toLowerCase();
    const manual = context.globalState.get('manualTasks', []) || [];
    const scanned = context.globalState.get('fileComments', []) || [];

    const results = [
        ...manual.filter(t => t.text.toLowerCase().includes(q)).map(t => ({
            ...formatTask(t, 'searchResult'),
            label: t.text,
            description: `📂 ${t.folder || 'General Workspace'}`
        })),
        ...scanned.filter(c => c.text.toLowerCase().includes(q)).map(c => ({
            ...formatTask(c, 'searchResult'),
            label: c.text,
            description: `📄 ${c.file}:${c.line}`
        }))
    ];

    return results.length > 0 ? results : [];
}

function getStandardItems(context, folderName) {
    const activeFilter = context.globalState.get('activeFilter', 'All Items') || 'All Items';
    const activeTagFilter = context.globalState.get('activeTagFilter', '') || '';
    const sortOrder = context.globalState.get('sortOrder', 'Default') || 'Default';
    const globalTags = context.globalState.get('itemTags', {}) || {};
    const trashData = context.globalState.get('trashData', []) || [];

    const getTag = (item) => {
        const key = item.id ? String(item.id) : `${item.file}:${item.line}`;
        return globalTags[key] || '';
    };

    // FIX: scanned items use file+line for trash check, manual use id
    const isInTrash = (item) => trashData.some(t =>
        item.file
            ? (t.originalFile === item.file && t.originalLine === item.line)
            : (String(t.id) === String(item.id))
    );

    let manual = (context.globalState.get('manualTasks', []) || [])
        .filter(t => t.folder === folderName && !isInTrash(t));

    // FIX: scanned items - properly show in their assigned tab
    let scanned = (context.globalState.get('fileComments', []) || [])
        .filter(c => (c.target || 'General Workspace') === folderName && !isInTrash(c));

    // Apply filters
    if (activeFilter === 'Manual Tasks Only') { scanned = []; }
    else if (activeFilter === 'Scanned Comments Only') { manual = []; }
    else if (activeFilter === 'Bugs Only (🔴)') {
        manual = manual.filter(t => getTag(t).includes('🐛') || getTag(t).toLowerCase().includes('bug'));
        scanned = scanned.filter(c => getTag(c).includes('🐛') || getTag(c).toLowerCase().includes('bug'));
    }
    else if (activeFilter === 'Untagged Items Only') {
        manual = manual.filter(t => !getTag(t));
        scanned = scanned.filter(c => !getTag(c));
    }
    else if (activeFilter === 'Specific Tag' && activeTagFilter) {
        manual = manual.filter(t => getTag(t) === activeTagFilter);
        scanned = scanned.filter(c => getTag(c) === activeTagFilter);
    }

    let combined = [
        ...manual.map(t => formatTask(t, 'standardTask')),
        ...scanned.map(c => formatTask(c, 'scannedTask'))
    ];

    // Apply sort
    if (sortOrder === 'A-Z (Alphabetical)') { combined.sort((a, b) => (a.label || '').localeCompare(b.label || '')); }
    else if (sortOrder.startsWith('Z-A')) { combined.sort((a, b) => (b.label || '').localeCompare(a.label || '')); }

    return combined;
}

function getRecycleItems(context) {
    return (context.globalState.get('trashData', []) || []).map(t => ({
        // FIX: map originalFile/originalLine to file/line so click-to-open works
        ...formatTask({
            ...t,
            file: t.originalFile || t.file || null,
            line: t.originalLine || t.line || null
        }, 'recycleTask'),
        description: `from: ${t.deletedFrom || 'Unknown'}`
    }));
}

// Standard task formatting
function formatTask(item, contextValue) {
    return {
        ...item,
        label: item.text,
        contextValue,
        collapsibleState: vscode.TreeItemCollapsibleState.None,
        iconPath: new vscode.ThemeIcon(
            item.file ? 'code' : 'record',
            new vscode.ThemeColor(item.file ? 'charts.blue' : 'charts.green')
        )
    };
}

// FIX: Priority tasks get a prefixed _vsTreeId to avoid VS Code tree ID conflicts
// when same task appears in both General and Priority tabs
function formatPriorityTask(item, contextValue) {
    const originalId = item.id || `${item.file}:${item.line}`;
    return {
        ...item,
        label: item.text,
        contextValue,
        collapsibleState: vscode.TreeItemCollapsibleState.None,
        _vsTreeId: `pri_${originalId}`,  // Used only for VS Code tree tracking
        iconPath: new vscode.ThemeIcon(
            item.file ? 'code' : 'record',
            new vscode.ThemeColor(item.file ? 'charts.blue' : 'charts.green')
        )
    };
}

module.exports = {
    getRoots, getStandardItems, getPriorityItems,
    getPriorityFolderItems, getRecycleItems, getSearchResults
};