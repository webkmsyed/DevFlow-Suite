// File: features/subTabs/general/generalTabIndex.js
const { registerGeneralTabPriority } = require('./generalTabPriority');
const { registerGeneralTabExport } = require('./generalTabExport');
const { registerGeneralTabDelete } = require('./generalTabDelete');
const { registerGeneralTabTaskCreate } = require('./generalTabTaskCreate');
const { recordHistory } = require('../../commands/historyOps');
const { logEvent } = require('../../engine/logger');
const vscode = require('vscode');

function registerGeneralTabOps(context, todoProvider, scanWorkspace) {
    registerGeneralTabTaskCreate(context, todoProvider);
    registerGeneralTabPriority(context, todoProvider);
    registerGeneralTabExport(context);
    registerGeneralTabDelete(context, todoProvider);

    // BUG 5 FIX: was stub "coming soon" — now real folder tagging
    context.subscriptions.push(vscode.commands.registerCommand('jargon.tabTag', async (node) => {
        if (!node) return;
        const folderName = node.originalText || node.label;
        const folderKey = `folder:${folderName}`;
        const tags = context.globalState.get('itemTags', {}) || {};
        const oldTag = tags[folderKey] || '';

        const newTag = await vscode.window.showInputBox({
            prompt: `Tag for folder: "${folderName}"`,
            value: oldTag,
            placeHolder: "Type tag name or 'clear' to remove"
        });

        if (newTag !== undefined) {
            recordHistory(context);
            if (newTag.trim() === '' || newTag.toLowerCase() === 'clear') {
                delete tags[folderKey];
                vscode.window.showInformationMessage(`DevFlow: Tag removed from '${folderName}'.`);
            } else {
                tags[folderKey] = newTag.trim();
                vscode.window.showInformationMessage(`DevFlow: '${folderName}' tagged as [${newTag.trim()}].`);
            }
            await context.globalState.update('itemTags', tags);
            todoProvider.refresh();
        }
    }));

    // Folder Sort redirect
    context.subscriptions.push(vscode.commands.registerCommand('jargon.tabSort', (node) => {
        vscode.commands.executeCommand('jargon.mainSort');
    }));

    // BUG 1 FIX: was 'jargon.mainFilter' (doesn't exist) → fixed to 'jargon.mainClearFilters'
    context.subscriptions.push(vscode.commands.registerCommand('jargon.tabFilter', (node) => {
        vscode.commands.executeCommand('jargon.mainClearFilters');
    }));

    // BUG 6 FIX: jargon.subFolderRename was NEVER registered anywhere
    context.subscriptions.push(vscode.commands.registerCommand('jargon.subFolderRename', async (node) => {
        if (!node) return;
        const oldName = node.originalText || node.label;

        if (oldName === 'General Workspace') {
            vscode.window.showWarningMessage("DevFlow: 'General Workspace' cannot be renamed.");
            return;
        }

        const newName = await vscode.window.showInputBox({
            prompt: `Rename folder "${oldName}" to:`,
            value: oldName,
            placeHolder: 'Enter new folder name'
        });

        if (!newName || newName.trim() === '' || newName.trim() === oldName) return;
        const trimmedName = newName.trim();

        const folders = context.globalState.get('userFolders', []) || [];
        if (folders.includes(trimmedName)) {
            vscode.window.showWarningMessage(`DevFlow: Folder '${trimmedName}' already exists!`);
            return;
        }

        recordHistory(context);

        // Update userFolders
        const updatedFolders = folders.map(f => f === oldName ? trimmedName : f);
        await context.globalState.update('userFolders', updatedFolders);

        // Update manual tasks
        let manualTasks = context.globalState.get('manualTasks', []) || [];
        manualTasks.forEach(t => { if (t.folder === oldName) t.folder = trimmedName; });
        await context.globalState.update('manualTasks', manualTasks);

        // Update scanned comments
        let fileComments = context.globalState.get('fileComments', []) || [];
        fileComments.forEach(c => { if (c.target === oldName) c.target = trimmedName; });
        await context.globalState.update('fileComments', fileComments);

        // Update priority tasks
        let priorityTasks = context.globalState.get('priorityTasks', []) || [];
        priorityTasks.forEach(p => {
            if (p.folder === oldName) p.folder = trimmedName;
            if (p.target === oldName) p.target = trimmedName;
            if (p.type === 'folder' && p.text === oldName) { p.text = trimmedName; p.id = `folder:${trimmedName}`; }
        });
        await context.globalState.update('priorityTasks', priorityTasks);

        // Migrate folder tag key
        let tags = context.globalState.get('itemTags', {}) || {};
        const oldKey = `folder:${oldName}`;
        const newKey = `folder:${trimmedName}`;
        if (tags[oldKey]) { tags[newKey] = tags[oldKey]; delete tags[oldKey]; }
        await context.globalState.update('itemTags', tags);

        todoProvider.refresh();
        logEvent(context, 'Update', `'${oldName}' 'Action -> Folder Renamed to ${trimmedName}'`);
        vscode.window.showInformationMessage(`DevFlow: Folder renamed to '${trimmedName}'.`);
    }));

    // BUG 7 FIX: jargon.subTaskSort was NEVER registered anywhere
    context.subscriptions.push(vscode.commands.registerCommand('jargon.subTaskSort', async (node) => {
        if (!node) return;
        const folderName = node.originalText || node.label;

        const mode = await vscode.window.showQuickPick([
            { label: 'A-Z (Alphabetical)', description: 'Sort tasks by name A to Z' },
            { label: 'Z-A (Reverse)', description: 'Sort tasks by name Z to A' },
            { label: 'Default (Time Added)', description: 'Restore original order' }
        ], { placeHolder: `Quick Sort: "${folderName}"` });

        if (mode) {
            await context.globalState.update('sortOrder', mode.label);
            todoProvider.refresh();
            vscode.window.showInformationMessage(`DevFlow: Sorted by ${mode.label}`);
        }
    }));
}

module.exports = { registerGeneralTabOps };