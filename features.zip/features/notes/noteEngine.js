// File: features/notes/noteEngine.js
const vscode = require('vscode');
const path = require('path');
const fs = require('fs');


const activePanels = {};

function registerNoteCommands(context) {
  context.subscriptions.push(vscode.commands.registerCommand('jargon.openNote', async (node) => {
    if (!node) return;
    const taskText = node.originalText || node.label;

    if (activePanels[taskText]) {
      activePanels[taskText].reveal(vscode.ViewColumn.Two);
      return;
    }

    const panel = vscode.window.createWebviewPanel(
      'devFlowNote',
      `📝 ${taskText.substring(0, 20)}${taskText.length > 20 ? '…' : ''}`,
      vscode.ViewColumn.Two,
      { enableScripts: true, retainContextWhenHidden: true }
    );

    activePanels[taskText] = panel;

    const allNotes = context.globalState.get('taskNotes', {});
    const currentNote = allNotes[taskText] || '';

    panel.webview.html = getNoteHTML(taskText, currentNote);

    panel.webview.onDidReceiveMessage(async (message) => {
      if (message.command === 'saveNote') {
        let notes = context.globalState.get('taskNotes', {});
        notes[taskText] = message.text;
        await context.globalState.update('taskNotes', notes);
      }

      if (message.command === 'exportNote') {
        await exportNote(taskText, message.text, message.format, message.imageData);
      }
    }, undefined, context.subscriptions);

    panel.onDidDispose(() => { delete activePanels[taskText]; }, null, context.subscriptions);
  }));
}

async function exportNote(taskText, noteText, format, imageData) {
  const workspaceRoot = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
  const safeTitle = taskText.replace(/[^a-z0-9]/gi, '_').substring(0, 30);
  const timestamp = new Date().toISOString().slice(0, 10);
  const fileName = `note_${safeTitle}_${timestamp}`;

  let savePath = null;

  if (format === 'md') {
    savePath = await vscode.window.showSaveDialog({
      defaultUri: vscode.Uri.file(path.join(workspaceRoot || '', `${fileName}.md`)),
      filters: { 'Markdown': ['md'] }
    });
    if (!savePath) return;
    const content = `# ${taskText}\n\n${noteText}`;
    fs.writeFileSync(savePath.fsPath, content, 'utf8');

  } else if (format === 'txt') {
    savePath = await vscode.window.showSaveDialog({
      defaultUri: vscode.Uri.file(path.join(workspaceRoot || '', `${fileName}.txt`)),
      filters: { 'Text File': ['txt'] }
    });
    if (!savePath) return;
    const content = `${taskText}\n${'='.repeat(taskText.length)}\n\n${noteText}`;
    fs.writeFileSync(savePath.fsPath, content, 'utf8');

  } else if (format === 'jpg' && imageData) {
    savePath = await vscode.window.showSaveDialog({
      defaultUri: vscode.Uri.file(path.join(workspaceRoot || '', `${fileName}.png`)),
      filters: { 'Image': ['png'] }
    });
    if (!savePath) return;
    const base64Data = imageData.replace(/^data:image\/\w+;base64,/, '');
    fs.writeFileSync(savePath.fsPath, Buffer.from(base64Data, 'base64'));
  }

  if (savePath) {
    const doc = await vscode.workspace.openTextDocument(savePath).catch(() => null);
    if (doc && format !== 'jpg') await vscode.window.showTextDocument(doc);
    vscode.window.showInformationMessage(`DevFlow: Note exported as ${format.toUpperCase()} ✓`);
  }
}

function getNoteHTML(taskTitle, noteContent) {
  // 1. Content escape karna taaki backticks aur $ signs HTML/JS break na karein
  const escaped = noteContent.replace(/\\/g, '\\\\').replace(/`/g, '\\`').replace(/\$/g, '\\$');

  // 2. Font settings (fontSize agar bahar se nahi aa raha toh default 14)
  const safeFontSize = (typeof fontSize !== 'undefined' && !isNaN(fontSize)) ? fontSize : 14;
  const fontString = `${safeFontSize}px 'JetBrains Mono', Consolas, monospace`;

  return `<!DOCTYPE html>
    <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Note</title>
          <style>
            * { box-sizing: border-box; margin: 0; padding: 0; }
            body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
            background: var(--vscode-editor-background);
            color: var(--vscode-editor-foreground);
            height: 100vh;
            display: flex;
            flex-direction: column;
            padding: 20px;
            gap: 16px;
                  }
            .header {
              display: flex;
              justify-content: space-between;
              align-items: center;
              padding-bottom: 12px;
              border-bottom: 1px solid rgba(128,128,128,0.15);
              flex-shrink: 0;
            }
            .title {
              font-size: 13px;
              font-weight: 600;
              opacity: 0.9;
              overflow: hidden;
              text-overflow: ellipsis;
              white-space: nowrap;
              max-width: 60%;
            }
            .header-right { display: flex; align-items: center; gap: 8px; }
            .status {
              font-size: 11px;
              opacity: 0.5;
              font-family: monospace;
            }
            .status.saving { opacity: 1; color: #f59e0b; }
            .export-btn {
              background: rgba(128,128,128,0.1);
              border: 1px solid rgba(128,128,128,0.2);
              color: inherit;
              font-size: 11px;
              padding: 4px 10px;
              border-radius: 5px;
              cursor: pointer;
            }
            .export-menu {
              position: absolute;
              top: 52px;
              right: 20px;
              background: var(--vscode-dropdown-background);
              border: 1px solid rgba(128,128,128,0.25);
              border-radius: 8px;
              display: none;
              z-index: 100;
              box-shadow: 0 8px 24px rgba(0,0,0,0.3);
            }
            .export-menu.open { display: block; }
            .export-option {
              padding: 9px 16px;
              font-size: 12px;
              cursor: pointer;
            }
            .export-option:hover { background: rgba(128,128,128,0.15); }
            textarea {
              flex: 1;
              width: 100%;
              background: rgba(128,128,128,0.04);
              border: 1px solid rgba(128,128,128,0.15);
              border-radius: 8px;
              padding: 14px 16px;
              color: var(--vscode-editor-foreground);
              font-size: 13px;
              font-family: 'JetBrains Mono', 'Fira Code', Consolas, monospace;
              line-height: 1.7;
              resize: none;
              outline: none;
            }
            canvas { display: none; }
          </style>
      </head>
  <body>
      <div class="header">
        <div class="title">${taskTitle}</div>
        <div class="header-right">
          <span class="status" id="status">Saved</span>
          <button class="export-btn" id="exportBtn">Export ↓</button>
        </div>
      </div>

      <div class="export-menu" id="exportMenu">
        <div class="export-option" onclick="doExport('md')">📄 Markdown (.md)</div>
        <div class="export-option" onclick="doExport('txt')">📝 Plain Text (.txt)</div>
        <div class="export-option" onclick="doExport('jpg')">🖼️ Image (.png)</div>
      </div>

      <textarea id="noteInput" placeholder="Write your notes...">${escaped}</textarea>
      <canvas id="exportCanvas"></canvas>

      <script>
        const vscode = acquireVsCodeApi();
        const textarea = document.getElementById('noteInput');
        const status = document.getElementById('status');
        const exportBtn = document.getElementById('exportBtn');
        const exportMenu = document.getElementById('exportMenu');
        let timeout = null;

        textarea.addEventListener('input', () => {
          status.textContent = 'Saving…';
          status.className = 'status saving';
          clearTimeout(timeout);
          timeout = setTimeout(() => {
            vscode.postMessage({ command: 'saveNote', text: textarea.value });
            status.textContent = 'Saved';
            status.className = 'status saved';
          }, 800);
        });

        exportBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          exportMenu.classList.toggle('open');
        });

        document.addEventListener('click', () => exportMenu.classList.remove('open'));

        function doExport(format) {
          exportMenu.classList.remove('open');
          if (format === 'jpg') {
            const canvas = document.getElementById('exportCanvas');
            const text = textarea.value;
            const lines = text.split('\\n');
            const padding = 40;
            const lineHeight = 22;
            const width = 800;
            const height = Math.max(400, 60 + padding * 2 + (lines.length) * lineHeight);
            
            canvas.width = width;
            canvas.height = height;
            const ctx = canvas.getContext('2d');

            // Background
            ctx.fillStyle = '#1e1e1e';
            ctx.fillRect(0, 0, width, height);

            // Title bar
            ctx.fillStyle = '#2d2d2d';
            ctx.fillRect(0, 0, width, 50);
            ctx.fillStyle = '#cccccc';
            ctx.font = 'bold 14px sans-serif';
            ctx.fillText("${taskTitle.replace(/"/g, '\\"')}", padding, 32);

            // Note text - Using the injected fontString
            ctx.font = "${fontString}"; 
            ctx.fillStyle = '#d4d4d4';
            lines.forEach((line, i) => {
              ctx.fillText(line, padding, 80 + i * lineHeight);
            });

            // Footer
            ctx.fillStyle = '#555';
            ctx.font = '11px sans-serif';
            ctx.fillText('DevFlow Suite', padding, height - 15);

            const imageData = canvas.toDataURL('image/png');
            vscode.postMessage({ command: 'exportNote', format: 'jpg', imageData, text: textarea.value });
          } else {
            vscode.postMessage({ command: 'exportNote', format, text: textarea.value });
          }
        }
      </script>
  </body>
</html>`;
}

module.exports = { registerNoteCommands };