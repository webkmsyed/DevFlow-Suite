// File: features/engine/scanner.js
const vscode = require('vscode');

function initScanner(context, todoProvider) {

    async function scanWorkspaceForComments() {
        try {
            const userFolders = context.globalState.get('userFolders', []) || [];

            // Find all code files, excluding noise folders
            const files = await vscode.workspace.findFiles(
                '**/*.{js,ts,jsx,tsx,py,html,css,java,c,cpp,cs,go,rb,php,swift,kt,rs}',
                '**/{node_modules,.git,dist,build,out,.next,.nuxt,coverage,__pycache__}/**'
            );

            if (!files.length) return;

            const comments = [];
            const existingComments = context.globalState.get('fileComments', []) || [];

            // Build a map of existing targets so we preserve user-assigned folders
            const existingTargetMap = {};
            existingComments.forEach(c => {
                existingTargetMap[`${c.file}:${c.line}`] = c.target;
            });

            for (const file of files) {
                let document;
                try {
                    document = await vscode.workspace.openTextDocument(file);
                } catch (e) { continue; }

                const relativePath = vscode.workspace.asRelativePath(file);
                const lines = document.getText().split('\n');

                lines.forEach((line, index) => {
                    const lineNum = index + 1;
                    // Match // comments — trimmed line that starts with //
                    const trimmed = line.trim();
                    if (!trimmed.startsWith('//')) return;

                    const commentText = trimmed.replace(/^\/\/\s*/, '').trim();
                    if (!commentText) return; // Skip empty comments

                    // Determine target folder:
                    // 1. Preserve user-assigned folder if exists
                    // 2. Auto-match by folder name prefix
                    // 3. Default to General Workspace
                    const key = `${relativePath}:${lineNum}`;
                    let targetFolder = existingTargetMap[key] || 'General Workspace';

                    if (!existingTargetMap[key]) {
                        for (const folder of userFolders) {
                            if (commentText.toLowerCase().startsWith(folder.toLowerCase())) {
                                targetFolder = folder;
                                break;
                            }
                        }
                    }

                    comments.push({
                        id: `${relativePath}:${lineNum}`,
                        text: commentText,
                        file: relativePath,
                        line: lineNum,
                        target: targetFolder
                    });
                });
            }

            await context.globalState.update('fileComments', comments);
            todoProvider.refresh();

        } catch (error) {
            console.error('DevFlow Scanner error:', error);
        }
    }

    // Auto-scan on file save
    vscode.workspace.onDidSaveTextDocument(() => scanWorkspaceForComments());

    // Manual scan command
    context.subscriptions.push(vscode.commands.registerCommand('jargon.mainRefresh', async () => {
        await scanWorkspaceForComments();
        vscode.window.showInformationMessage('DevFlow: Workspace scanned ✓');
    }));

    // Scan on startup (after 800ms to let VS Code settle)
    setTimeout(scanWorkspaceForComments, 800);

    return scanWorkspaceForComments;
}

module.exports = { initScanner };