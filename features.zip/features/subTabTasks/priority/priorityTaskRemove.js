// File: features/subTabTasks/priority/priorityTaskRemove.js
const vscode = require('vscode');
const { logEvent } = require('../../engine/logger');

function registerPriorityTaskRemove(context, todoProvider) {
    // BUG 4 FIX: was 'jargon.priTaskRemove' — package.json needs 'jargon.taskRemovePri'
    context.subscriptions.push(vscode.commands.registerCommand('jargon.taskRemovePri', async (node) => {
        if (!node) return;
        let pri = context.globalState.get('priorityTasks', []) || [];
        const nodeId = node.id || `${node.file}:${node.line}`;

        pri = pri.filter(p => (p.id || `${p.file}:${p.line}`) !== nodeId);

        await context.globalState.update('priorityTasks', pri);
        todoProvider.refresh();
        logEvent(context, 'Priority', `'${node.originalText}' 'Action -> Removed from Priority'`);
        vscode.window.showInformationMessage(`DevFlow: Removed from Priority.`);
    }));
}

module.exports = { registerPriorityTaskRemove };